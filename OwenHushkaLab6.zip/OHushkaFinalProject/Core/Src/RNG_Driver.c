
#include"RNG_Driver.h"
#include"ApplicationCode.h"


//static GPIO_InitTypeDef GYRO_Ctrl;
//static SPI_HandleTypeDef handle;
//static HAL_StatusTypeDef gyroHALStatus;



//will be really similar to how we run the button
void RNG_Init(RNG_HandleTypeDef *RNG_Handle){


	//Control Register: Interrupt enable and Random number generation enable
	//Status Register: Errors and Data Ready Bit

	RNG_Handle->Instance=RNG;


	//Do i need to set HAL_LockTypeDef
	//Do i need to set HAL_RNG_StateTypeDef?

	RNG_Handle->Instance->CR |= 0b100;


	//enable clock
	HAL_RNG_MspInit(RNG_Handle); //__HAL_RCC_RNG_CLK_ENABLE();   //or is it this second one im not sure lol

	//enable interrupt mode
	//can do this by using a bitmask 0x6

	//(#) Enable the RNG controller clock using __HAL_RCC_RNG_CLK_ENABLE() macro in HAL_RNG_MspInit().
	//(#) Activate the RNG peripheral using HAL_RNG_Init() function.
	//(#) Wait until the 32 bit Random Number Generator contains a valid
	//random data using (polling/interrupt) mode.


	if(HAL_OK != HAL_RNG_Init(RNG_Handle)){
		//return error?
	}
}




uint32_t RNG_GetNum(RNG_HandleTypeDef RNG_Handle){
	uint32_t randNum;
	//(#) Get the 32 bit random number using HAL_RNG_GenerateRandomNumber() function.
	//just need to read the data register?
	//must check DRDY bit before trying to read in data (Bit 0 of SR register)

	HAL_RNG_GenerateRandomNumber(&RNG_Handle, &randNum);
	return randNum;

	//uint32_t HAL_RNG_ReadLastRandomNumber(RNG_HandleTypeDef *hrng)
	//could use this and call this every time a new number is generated


}

