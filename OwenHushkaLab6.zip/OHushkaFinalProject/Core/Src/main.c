/* USER CODE BEGIN Header */
// This file is Main.c

#include "main.h"
#include "ApplicationCode.h"
#include"Scheduler.h"
#include <stdio.h>
extern void initialise_monitor_handles(void);

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
void systemClockOverride(void);


//0b11111111111111111111111111111111 = 2^32-1
#define MAX_RAND 4294967295 //The maximum value the random number generator can generate


int main(void)
{
	initialise_monitor_handles();
	uint32_t tim4 = 0;
	uint32_t tim3 = 0;
	uint32_t tickStart;
	uint32_t tim1 = 0;
	uint32_t tim2 = 0;
    uint32_t eventsToRun = 0;
	uint32_t rand;

	int numDigits1;
	int numDigits2;
	int numDigits3;
	int numDigits4;
	int numDigits5;
	int numDigits6;

	RNG_HandleTypeDef RNG_Handle;
	RNG_Init(&RNG_Handle);
    HAL_Init();
    ApplicationInit();
    systemClockOverride();


    //print the instructions for the first game
    PrintInstructions();
    removeSchedulerEvent(ButtonPressedEvent);
    eventsToRun |= getScheduledEvents();

    while(!(eventsToRun & ButtonPressedEvent)){ //while the user has not pressed the button
    	eventsToRun |= getScheduledEvents(); //check if the user has pressed the button
    }
    //once the button is pressed, we can move on and begin the first game



    /* Reset of all peripherals, Initializes the Flash interface and the Systick. */

    uint16_t x = 20;
    uint16_t y = 20;
    uint16_t x1 = 100;
    uint16_t y1 = 100;

  rand = RNG_GetNum(RNG_Handle); //get random number using the HAL's RNG_GetNum() function

  //for a random amount of time display a triangle on the screen
  while(rand > (MAX_RAND / 2.5)){
	  LCD_Clear(0, LCD_COLOR_WHITE);
	  LCD_Display_Triangle(x1, y1);
	  DelayTime(rand, RNG_Handle);
	  rand = RNG_GetNum(RNG_Handle);
  }

  DelayTime(rand, RNG_Handle);

  LCD_Clear(0, LCD_COLOR_WHITE);
  LCD_Display_Square(100, 100); //display square to signal the user should press the button

  tickStart = HAL_GetTick(); //save the time of the start of the event

  eventsToRun &= BUTTON_EVENT_CLEAR;
  removeSchedulerEvent(ButtonPressedEvent);
  while(!(eventsToRun & ButtonPressedEvent)){ //wait for button
	eventsToRun |= getScheduledEvents();
  }

  tim1 = HAL_GetTick() - tickStart; //find the difference between the start time and the time the user presses the button
  numDigits1 = GetNumDigits(tim1);
  uint8_t arr1[numDigits1];
  SeperateCharacters(tim1, &arr1); //store this time value as an array of digits


  //clear the screen and print instructions for the second game
  LCD_Clear(0, LCD_COLOR_WHITE);
  printInstruction2();
  Delay();


  removeSchedulerEvent(ButtonPressedEvent);
  eventsToRun &= BUTTON_EVENT_CLEAR;
  while(!(eventsToRun & ButtonPressedEvent)){ //again wait for user to press button before begining the game
	eventsToRun |= getScheduledEvents();
  }

  LCD_Clear(0, LCD_COLOR_WHITE);
  rand = RNG_GetNum(RNG_Handle);
  LCD_Display_Grid();


  //randomly display the circle in different quadrants of the grid
  while((rand < (MAX_RAND / 2)) || (rand > ((MAX_RAND * 3) / 4))){
	  LCD_Clear(0, LCD_COLOR_WHITE);
	  LCD_Display_Grid();

	  if(rand < (MAX_RAND / 4)){
		  LCD_Draw_Circle_Fill(60, 80, 10, LCD_COLOR_MAGENTA);
		  HAL_GetTick();
	  }
	  else if(rand < (MAX_RAND / 2)){
		  LCD_Draw_Circle_Fill(180, 80, 10, LCD_COLOR_MAGENTA);
	  }
	  else{
		  LCD_Draw_Circle_Fill(180, 240, 10, LCD_COLOR_MAGENTA);
	  }
	  rand = RNG_GetNum(RNG_Handle);
	  DelayTime(rand, RNG_Handle);
  }
  //clear and display the circle in the bottom left corner
  //the user is instructed to wait until the circle is in the
  //bottom left corner and then they press the button
  LCD_Clear(0, LCD_COLOR_WHITE);
  LCD_Display_Grid();
  LCD_Draw_Circle_Fill(60, 240, 10, LCD_COLOR_MAGENTA);

  tickStart = HAL_GetTick(); //get the start time
  removeSchedulerEvent(ButtonPressedEvent); //make sure there is not a left over button event
  eventsToRun &= BUTTON_EVENT_CLEAR; //manually clear the event
  while(!(eventsToRun & ButtonPressedEvent)){
	eventsToRun |= getScheduledEvents();
  }

  tim1 = HAL_GetTick() - tickStart; //find the reaction time

  LCD_Clear(0, LCD_COLOR_WHITE);
  printInstruction3();

  numDigits2 = GetNumDigits(tim1);
  uint8_t arr2[numDigits2];
  SeperateCharacters(tim1, &arr2);

  removeSchedulerEvent(ButtonPressedEvent);
  eventsToRun &= BUTTON_EVENT_CLEAR;
  //Until the user presses the button signaling they are ready to begin the third game, display the instructions and wait
  while(!(eventsToRun & ButtonPressedEvent)){
	eventsToRun |= getScheduledEvents();
  }



   //LCD_Display_Moving_Ball();

	LCD_Display_Ball1(0);//
	tickStart = HAL_GetTick();
	removeSchedulerEvent(ButtonPressedEvent);
	eventsToRun &= BUTTON_EVENT_CLEAR;
	while(!(eventsToRun & ButtonPressedEvent)){
		eventsToRun |= getScheduledEvents();
	}
	tim1 = HAL_GetTick() - tickStart;

	LCD_Display_Ball2();
	tickStart = HAL_GetTick();
	removeSchedulerEvent(ButtonPressedEvent);
	eventsToRun &= BUTTON_EVENT_CLEAR;
	while(!(eventsToRun & ButtonPressedEvent)){
		eventsToRun |= getScheduledEvents();
	}
	tim2 = HAL_GetTick() - tickStart;

	LCD_Display_Ball1(30);
	tickStart = HAL_GetTick();
	removeSchedulerEvent(ButtonPressedEvent);
	eventsToRun &= BUTTON_EVENT_CLEAR;
	while(!(eventsToRun & ButtonPressedEvent)){
		eventsToRun |= getScheduledEvents();
	}
	tim3 = HAL_GetTick() - tickStart;


	LCD_Display_Ball2();
	tickStart = HAL_GetTick();
	removeSchedulerEvent(ButtonPressedEvent);
	eventsToRun &= BUTTON_EVENT_CLEAR;
	while(!(eventsToRun & ButtonPressedEvent)){
		eventsToRun |= getScheduledEvents();
	}
	tim4 = HAL_GetTick() - tickStart;


  //need to watch for if systic resets

  removeSchedulerEvent(ButtonPressedEvent);
  eventsToRun &= BUTTON_EVENT_CLEAR;



  numDigits3 = GetNumDigits(tim1);
  uint8_t arr3[numDigits3];
  SeperateCharacters(tim1, &arr3);

  numDigits4 = GetNumDigits(tim2);
  uint8_t arr4[numDigits4];
  SeperateCharacters(tim2, &arr4);

  numDigits5 = GetNumDigits(tim3);
  uint8_t arr5[numDigits5];
  SeperateCharacters(tim3, &arr5);


  numDigits6 = GetNumDigits(tim4);
  uint8_t arr6[numDigits6];
  SeperateCharacters(tim4, &arr6);


  //printing the results

  uint8_t asci[7]= {'R', 'e', 's', 'u', 'l', 't', 's'};
  uint8_t asci2[9] = {'T', 'e', 's', 't', 32, '1', 32, ':', 32};
  uint8_t asci3[9] = {'T', 'e', 's', 't', 32, '2', 32, ':', 32};
  uint8_t asci4[9] = {'T', 'e', 's', 't', 32, '3', 32, ':', 32};
  uint8_t asci5[9] = {'T', 'e', 's', 't', 32, '4', 32, ':', 32};
  uint8_t asci6[9] = {'T', 'e', 's', 't', 32, '5', 32, ':', 32};

  LCD_SetTextColor(LCD_COLOR_BLACK);
  LCD_SetFont(&Font16x24);
  for(int i = 0; i < 7; i++){
	LCD_DisplayChar((x + (12 * i)), y, asci[i]);}

  LCD_SetFont(&Font12x12);
  y = y+20;

  for(int i = 0; i < 9; i++){
	LCD_DisplayChar((x + (7.5 * i)), y, asci2[i]);}
  x = 80;
  for(int i = 0; i < numDigits1; i++){
	  LCD_DisplayChar(x + (7*i), y, arr1[i]);
  }
  y = y+20;
  x = 20;
  for(int i = 0; i < 9; i++){
	LCD_DisplayChar((x + (7.5 * i)), y, asci3[i]);}
  x = 80;
  for(int i = 0; i < numDigits2; i++){
	  LCD_DisplayChar(x + (7*i), y, arr2[i]);
  }
  y = y+20;
  x = 20;
  for(int i = 0; i < 9; i++){
	LCD_DisplayChar((x + (7.5 * i)), y, asci4[i]);}
  x = 80;
  for(int i = 0; i < numDigits3; i++){
	  LCD_DisplayChar(x + (7*i), y, arr3[i]);
  }
  y = y+20;
  x = 20;
  for(int i = 0; i < 9; i++){
	LCD_DisplayChar((x + (7.5 * i)), y, asci5[i]);}
  x = 80;
  for(int i = 0; i < numDigits4; i++){
	  LCD_DisplayChar(x + (7*i), y, arr4[i]);
  }
  y = y+20;
  x = 20;
  for(int i = 0; i < 9; i++){
	LCD_DisplayChar((x + (7.5 * i)), y, asci6[i]);}
  x = 80;
  for(int i = 0; i < numDigits5; i++){
	  LCD_DisplayChar(x + (7*i), y, arr5[i]);
  }






//4294967295
  while(1)
  {
	  eventsToRun |= getScheduledEvents();
//	  if(eventsToRun & ButtonPressedEvent){
//		  LCD_Display_Square(150, 150);
//	  }
  }
}




/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 50;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV8;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV4;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

void systemClockOverride(void)
{
  RCC_ClkInitTypeDef RCC_ClkInitStruct;
  RCC_OscInitTypeDef RCC_OscInitStruct;

  __HAL_RCC_PWR_CLK_ENABLE();

  // __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1); // not needed, power scaling consumption for when not running at max freq.

  /* Enable HSE Osc and activate PLL with HSE source */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  HAL_RCC_OscConfig(&RCC_OscInitStruct);

  /* Select PLL as system clock source and configure the HCLK, PCLK1 and PCLK2 clocks dividers */
  RCC_ClkInitStruct.ClockType = (RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2);
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5);
}


// /**
//   * @brief GPIO Initialization Function
//   * @param None
//   * @retval None
//   */
// static void MX_GPIO_Init(void)
// {
//   GPIO_InitTypeDef GPIO_InitStruct = {0};
// /* USER CODE BEGIN MX_GPIO_Init_1 */
// /* USER CODE END MX_GPIO_Init_1 */

//   /* GPIO Ports Clock Enable */
//   __HAL_RCC_GPIOC_CLK_ENABLE();
//   __HAL_RCC_GPIOF_CLK_ENABLE();
//   __HAL_RCC_GPIOH_CLK_ENABLE();
//   __HAL_RCC_GPIOA_CLK_ENABLE();
//   __HAL_RCC_GPIOB_CLK_ENABLE();
//   __HAL_RCC_GPIOG_CLK_ENABLE();
//   __HAL_RCC_GPIOE_CLK_ENABLE();
//   __HAL_RCC_GPIOD_CLK_ENABLE();

//   /*Configure GPIO pin Output Level */
//   HAL_GPIO_WritePin(GPIOC, NCS_MEMS_SPI_Pin|CSX_Pin|OTG_FS_PSO_Pin, GPIO_PIN_RESET);

//   /*Configure GPIO pin Output Level */
//   HAL_GPIO_WritePin(ACP_RST_GPIO_Port, ACP_RST_Pin, GPIO_PIN_RESET);

//   /*Configure GPIO pin Output Level */
//   HAL_GPIO_WritePin(GPIOD, RDX_Pin|WRX_DCX_Pin, GPIO_PIN_RESET);

//   /*Configure GPIO pin Output Level */
//   HAL_GPIO_WritePin(GPIOG, LD3_Pin|LD4_Pin, GPIO_PIN_RESET);

//   /*Configure GPIO pins : A0_Pin A1_Pin A2_Pin A3_Pin
//                            A4_Pin A5_Pin SDNRAS_Pin A6_Pin
//                            A7_Pin A8_Pin A9_Pin */
//   GPIO_InitStruct.Pin = A0_Pin|A1_Pin|A2_Pin|A3_Pin
//                           |A4_Pin|A5_Pin|SDNRAS_Pin|A6_Pin
//                           |A7_Pin|A8_Pin|A9_Pin;
//   GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
//   GPIO_InitStruct.Pull = GPIO_NOPULL;
//   GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
//   GPIO_InitStruct.Alternate = GPIO_AF12_FMC;
//   HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

//   /*Configure GPIO pin : SDNWE_Pin */
//   GPIO_InitStruct.Pin = SDNWE_Pin;
//   GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
//   GPIO_InitStruct.Pull = GPIO_NOPULL;
//   GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
//   GPIO_InitStruct.Alternate = GPIO_AF12_FMC;
//   HAL_GPIO_Init(SDNWE_GPIO_Port, &GPIO_InitStruct);

//   /*Configure GPIO pins : NCS_MEMS_SPI_Pin CSX_Pin OTG_FS_PSO_Pin */
//   GPIO_InitStruct.Pin = NCS_MEMS_SPI_Pin|CSX_Pin|OTG_FS_PSO_Pin;
//   GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
//   GPIO_InitStruct.Pull = GPIO_NOPULL;
//   GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
//   HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

//   /*Configure GPIO pins : B1_Pin MEMS_INT1_Pin MEMS_INT2_Pin TP_INT1_Pin */
//   GPIO_InitStruct.Pin = B1_Pin|MEMS_INT1_Pin|MEMS_INT2_Pin|TP_INT1_Pin;
//   GPIO_InitStruct.Mode = GPIO_MODE_EVT_RISING;
//   GPIO_InitStruct.Pull = GPIO_NOPULL;
//   HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

//   /*Configure GPIO pin : ACP_RST_Pin */
//   GPIO_InitStruct.Pin = ACP_RST_Pin;
//   GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
//   GPIO_InitStruct.Pull = GPIO_NOPULL;
//   GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
//   HAL_GPIO_Init(ACP_RST_GPIO_Port, &GPIO_InitStruct);

//   /*Configure GPIO pin : OTG_FS_OC_Pin */
//   GPIO_InitStruct.Pin = OTG_FS_OC_Pin;
//   GPIO_InitStruct.Mode = GPIO_MODE_EVT_RISING;
//   GPIO_InitStruct.Pull = GPIO_NOPULL;
//   HAL_GPIO_Init(OTG_FS_OC_GPIO_Port, &GPIO_InitStruct);

//   /*Configure GPIO pin : BOOT1_Pin */
//   GPIO_InitStruct.Pin = BOOT1_Pin;
//   GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
//   GPIO_InitStruct.Pull = GPIO_NOPULL;
//   HAL_GPIO_Init(BOOT1_GPIO_Port, &GPIO_InitStruct);

//   /*Configure GPIO pins : A10_Pin A11_Pin BA0_Pin BA1_Pin
//                            SDCLK_Pin SDNCAS_Pin */
//   GPIO_InitStruct.Pin = A10_Pin|A11_Pin|BA0_Pin|BA1_Pin
//                           |SDCLK_Pin|SDNCAS_Pin;
//   GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
//   GPIO_InitStruct.Pull = GPIO_NOPULL;
//   GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
//   GPIO_InitStruct.Alternate = GPIO_AF12_FMC;
//   HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);

//   /*Configure GPIO pins : D4_Pin D5_Pin D6_Pin D7_Pin
//                            D8_Pin D9_Pin D10_Pin D11_Pin
//                            D12_Pin NBL0_Pin NBL1_Pin */
//   GPIO_InitStruct.Pin = D4_Pin|D5_Pin|D6_Pin|D7_Pin
//                           |D8_Pin|D9_Pin|D10_Pin|D11_Pin
//                           |D12_Pin|NBL0_Pin|NBL1_Pin;
//   GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
//   GPIO_InitStruct.Pull = GPIO_NOPULL;
//   GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
//   GPIO_InitStruct.Alternate = GPIO_AF12_FMC;
//   HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

//   /*Configure GPIO pins : OTG_HS_ID_Pin OTG_HS_DM_Pin OTG_HS_DP_Pin */
//   GPIO_InitStruct.Pin = OTG_HS_ID_Pin|OTG_HS_DM_Pin|OTG_HS_DP_Pin;
//   GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
//   GPIO_InitStruct.Pull = GPIO_NOPULL;
//   GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
//   GPIO_InitStruct.Alternate = GPIO_AF12_OTG_HS_FS;
//   HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

//   /*Configure GPIO pin : VBUS_HS_Pin */
//   GPIO_InitStruct.Pin = VBUS_HS_Pin;
//   GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
//   GPIO_InitStruct.Pull = GPIO_NOPULL;
//   HAL_GPIO_Init(VBUS_HS_GPIO_Port, &GPIO_InitStruct);

//   /*Configure GPIO pins : D13_Pin D14_Pin D15_Pin D0_Pin
//                            D1_Pin D2_Pin D3_Pin */
//   GPIO_InitStruct.Pin = D13_Pin|D14_Pin|D15_Pin|D0_Pin
//                           |D1_Pin|D2_Pin|D3_Pin;
//   GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
//   GPIO_InitStruct.Pull = GPIO_NOPULL;
//   GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
//   GPIO_InitStruct.Alternate = GPIO_AF12_FMC;
//   HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

//   /*Configure GPIO pin : TE_Pin */
//   GPIO_InitStruct.Pin = TE_Pin;
//   GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
//   GPIO_InitStruct.Pull = GPIO_NOPULL;
//   HAL_GPIO_Init(TE_GPIO_Port, &GPIO_InitStruct);

//   /*Configure GPIO pins : RDX_Pin WRX_DCX_Pin */
//   GPIO_InitStruct.Pin = RDX_Pin|WRX_DCX_Pin;
//   GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
//   GPIO_InitStruct.Pull = GPIO_NOPULL;
//   GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
//   HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

//   /*Configure GPIO pin : I2C3_SDA_Pin */
//   GPIO_InitStruct.Pin = I2C3_SDA_Pin;
//   GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
//   GPIO_InitStruct.Pull = GPIO_NOPULL;
//   GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
//   GPIO_InitStruct.Alternate = GPIO_AF4_I2C3;
//   HAL_GPIO_Init(I2C3_SDA_GPIO_Port, &GPIO_InitStruct);

//   /*Configure GPIO pin : I2C3_SCL_Pin */
//   GPIO_InitStruct.Pin = I2C3_SCL_Pin;
//   GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
//   GPIO_InitStruct.Pull = GPIO_NOPULL;
//   GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
//   GPIO_InitStruct.Alternate = GPIO_AF4_I2C3;
//   HAL_GPIO_Init(I2C3_SCL_GPIO_Port, &GPIO_InitStruct);

//   /*Configure GPIO pins : STLINK_RX_Pin STLINK_TX_Pin */
//   GPIO_InitStruct.Pin = STLINK_RX_Pin|STLINK_TX_Pin;
//   GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
//   GPIO_InitStruct.Pull = GPIO_NOPULL;
//   GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
//   GPIO_InitStruct.Alternate = GPIO_AF7_USART1;
//   HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

//   /*Configure GPIO pins : LD3_Pin LD4_Pin */
//   GPIO_InitStruct.Pin = LD3_Pin|LD4_Pin;
//   GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
//   GPIO_InitStruct.Pull = GPIO_NOPULL;
//   GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
//   HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);

//   /*Configure GPIO pins : SDCKE1_Pin SDNE1_Pin */
//   GPIO_InitStruct.Pin = SDCKE1_Pin|SDNE1_Pin;
//   GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
//   GPIO_InitStruct.Pull = GPIO_NOPULL;
//   GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
//   GPIO_InitStruct.Alternate = GPIO_AF12_FMC;
//   HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);



/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
