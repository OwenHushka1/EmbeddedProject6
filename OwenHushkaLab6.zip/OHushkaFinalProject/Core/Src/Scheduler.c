/*
 * Scheduler.c
 *
 *  Created on: Sep 5, 2023
 *      Author: owenhushka
 */

#include<Scheduler.h>


static uint32_t scheduledEvents; //variable to store events that need to run


void addSchedulerEvent(uint32_t event){

	scheduledEvents |= event;

}

void removeSchedulerEvent(uint32_t event){

	scheduledEvents &= ~event;//should be anding it

}


uint32_t getScheduledEvents(){

	return scheduledEvents;
}



