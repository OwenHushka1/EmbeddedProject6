/*
 * ApplicationCode.c
 *
 *  Created on: Nov 14, 2023
 *      Author: xcowa
 */

#include "ApplicationCode.h"
#include "InterruptControl.h"

#define TIM5IRQ 50  //IRQ numbers for different interrupts. Not used in this project
#define TIM2IRQ 28


void ApplicationInit(void)
{
	LTCD__Init();
    LTCD_Layer_Init(0);
    LCD_Clear(0,LCD_COLOR_WHITE);
    InitializeInterruptMode();
}


void RunDemoForLCD(void)
{
	QuickDemo();
}


//A somewhat archaic Delay function which we were instructed to create this way
void Delay(){
	char arr[NAME_LENGTH] = "Owen";
	[[maybe_unused]]char destination[NAME_LENGTH];

	for(int i = 0; i < DELAY; i++){
		for(int k = 0; k < 4; k++){
			destination[k] = arr[k];
		}
	}
}

//A version of the delay function which I created to provide a delay which is proportional to the number
//which is sent into the function
void DelayTime(uint32_t num, RNG_HandleTypeDef RNG_Handle){

	while(num >= 10000000){
		num = num/10;
	}
	char arr[NAME_LENGTH] = "Owen";
	[[maybe_unused]]char destination[NAME_LENGTH];
	for(int i = 0; i < num; i++){
		for(int k = 0; k < 2; k++){
			destination[k] = arr[k];
		}
	}
}

void InitializeInterruptMode(){
	Initialize_Interrupt_Mode();
}


void Button_Init(){
	Initialize_Button();
}




void PrintInstructions(){

	uint16_t x_pos = 15;
	uint16_t y_pos = 40;

	uint8_t ascii[13]={'R','e','f','l','e','x', 32, 'T', 'e', 's', 't', 'e', 'r'};
	uint8_t ascii2[29] = {'C', 'l', 'i', 'c', 'k', 32, 'W', 'h', 'e', 'n', 32, 'Y', 'o', 'u', 32, 'S', 'e', 'e', 32, 'T', 'h', 'e', 32, 'S', 'q', 'u', 'a', 'r', 'e'};
	uint8_t arr[23] = {'P', 'r', 'e', 's', 's', 32, 'B', 'u', 't', 't', 'o', 'n', 32, 'W', 'h', 'e', 'n', 32, 'R', 'e', 'a', 'd', 'y'};

  LCD_SetTextColor(LCD_COLOR_BLACK);
  LCD_SetFont(&Font16x24);
  for(int i = 0; i < 13; i++){
	LCD_DisplayChar((x_pos + (12 * i)), y_pos, ascii[i]);}

  LCD_SetFont(&Font12x12);
  y_pos = 80;
  x_pos = 3;
  for(int i = 0; i < 29; i++){
	LCD_DisplayChar((x_pos + (7.5 * i)), y_pos, ascii2[i]);
  }
  y_pos = 100;

  	for(int i = 0; i < 23; i++){
  		LCD_DisplayChar((x_pos + (7.5 * i)), y_pos, arr[i]);
  	}
}

void PrintInstruction(){
	uint16_t x_pos = 3;
	uint16_t y_pos = 40;
	uint8_t ascii2[29] = {'C', 'l', 'i', 'c', 'k', 32, 'W', 'h', 'e', 'n', 32, 'Y', 'o', 'u', 32, 'S', 'e', 'e', 32, 'T', 'h', 'e', 32, 'S', 'q', 'u', 'a', 'r', 'e'};
	uint8_t arr[23] = {'P', 'r', 'e', 's', 's', 32, 'B', 'u', 't', 't', 'o', 'n', 32, 'W', 'h', 'e', 'n', 32, 'R', 'e', 'a', 'd', 'y'};
	LCD_SetFont(&Font12x12);
	LCD_SetTextColor(LCD_COLOR_BLACK);

	for(int i = 0; i < 29; i++){
		LCD_DisplayChar((x_pos + (7.5 * i)), y_pos, ascii2[i]);
	}

	y_pos = 60;

	for(int i = 0; i < 23; i++){
		LCD_DisplayChar((x_pos + (7.5 * i)), y_pos, arr[i]);
	}
}


void printInstruction2(){

	uint16_t x_pos = 3;
	uint16_t y_pos = 40;
	uint8_t ascii3[27] = {'C', 'l', 'i', 'c', 'k', 32, 'W', 'h', 'e', 'n', 32, 'Y', 'o', 'u', 32, 'S', 'e', 'e', 32, 'A', 32, 'S', 'q', 'u', 'a', 'r', 'e'};
	uint8_t ascii4[22] = {'I', 'n', 32, 'T', 'h', 'e', 32, 'L', 'o', 'w', 32, 'L', 'e', 'f', 't', 32, 'C', 'o', 'r', 'n', 'e', 'r'};
	uint8_t arr[23] = {'P', 'r', 'e', 's', 's', 32, 'B', 'u', 't', 't', 'o', 'n', 32, 'W', 'h', 'e', 'n', 32, 'R', 'e', 'a', 'd', 'y'};

	LCD_SetFont(&Font12x12);
	LCD_SetTextColor(LCD_COLOR_BLACK);

	for(int i = 0; i < 27; i++){
		LCD_DisplayChar((x_pos + (7.5 * i)), y_pos, ascii3[i]);
	}
	y_pos = 60;
	for(int i = 0; i < 22; i++){
		LCD_DisplayChar((x_pos + (7.5 * i)), y_pos, ascii4[i]);
	}
	y_pos = 80;
	for(int i = 0; i < 23; i++){
		LCD_DisplayChar((x_pos + (7.5 * i)), y_pos, arr[i]);
	}
}


void printInstruction3(){

	uint16_t x_pos = 3;
	uint16_t y_pos = 40;
	LCD_SetFont(&Font12x12);
	LCD_SetTextColor(LCD_COLOR_BLACK);

	uint8_t ascii[19] = {'C', 'l', 'i', 'c', 'k', 32, 'W', 'h', 'e', 'n', 32, 'T', 'h', 'e', 32, 'B', 'a', 'l', 'l'};
	uint8_t ascii2[23] = {'C', 'r', 'o', 's', 's', 'e', 's', 32, 'T', 'h', 'e', 32, 'C', 'e', 'n', 't', 'e', 'r', 32, 'L', 'i', 'n', 'e'};
	uint8_t arr[23] = {'P', 'r', 'e', 's', 's', 32, 'B', 'u', 't', 't', 'o', 'n', 32, 'W', 'h', 'e', 'n', 32, 'R', 'e', 'a', 'd', 'y'};

	for(int i = 0; i < 19; i++){
		LCD_DisplayChar((x_pos + (7.5 * i)), y_pos, ascii[i]);
	}
	y_pos = 60;
	for(int i = 0; i < 23; i++){
		LCD_DisplayChar((x_pos + (7.5 * i)), y_pos, ascii2[i]);
	}
	y_pos = 80;
	for(int i = 0; i < 23; i++){
		LCD_DisplayChar((x_pos + (7.5 * i)), y_pos, arr[i]);
	}
}


//function which takes a number and a pointer to an array
//and populates the array with the individual ascii values of each digit
int SeperateCharacters(uint32_t num, uint8_t *arr){
	int power=1;
	int i = 0;

	while(num>power)
		power*=10;

	power/=10;

	while(num != 0)
	    {
        int digit = num /power;
        arr[i] = (uint8_t)digit;
        i++;
        if(digit!=0)
          num=num-digit*power;
        if(power!=1)
          power/=10;
    }
	CharactersToAscii(arr, i);
	return i;
}

//function which takes a character and changes its value to be the character's ascii value
void CharactersToAscii(char *arr, int size){

	for(int i = 0; i < size; i++){
		arr[i] = arr[i] + 48;
	}
}

//function to get the number of digits in a number. Used to create an array to store the digits of a number
int GetNumDigits(uint32_t num){
	int power = 1;
	int i = 0;
	if(num > 100000){
		power=100;
		num/=100;
		i = 2;
	}
	while(num>power){
		power*=10;
		i++;
	}
	return i;
}

//Interrupt handler for the interrupt which is triggered by the user pressing the button
void EXTI0_IRQHandler(){
	IRQ_DISABLE_INTERRUPT(EXTI0_IRQ_NUMBER);
	addSchedulerEvent(ButtonPressedEvent);
	EXTI_INTERRUPT_CLEAR(BUTTON_PIN);
	IRQ_ENABLE_INTERRUPT(EXTI0_IRQ_NUMBER);
	IRQ_ENABLE_INTERRUPT(TIM2IRQ); //there is a bug where when we disable the interrupt for EXTI0 it also disables it for TIM2

}


//IRQ handler for TIM2 interrupt. Unused in this project
void TIM2_IRQHandler(){
	IRQ_DISABLE_INTERRUPT(TIM2IRQ);
	//EXTI_PR set to 0 to clear flag
	//still need to clear NVIC interrupt?
	IRQ_ENABLE_INTERRUPT(EXTI0_IRQ_NUMBER);
	if(TIM2->SR & (1<<1)){
		#if USE_LIMITED_RESOURCES == 0

		#else

		#endif
	}
	(TIM2->SR &= ~(1<<1));
	IRQ_CLEAR_INTERRUPT(TIM2IRQ);
	IRQ_ENABLE_INTERRUPT(TIM2IRQ);

}
//IRQ handler for TIM5 interrupt. Unused in this project
void TIM5_IRQHandler(){
	IRQ_DISABLE_INTERRUPT(TIM5IRQ);
	//IRQ_ENABLE_INTERRUPT(6);
	if(TIM5->SR & (1<<1)){
	#if USE_LIMITED_RESOURCES == 0

	#else

	#endif
	}
	((TIM5->SR) &= ~(1<<1));
	IRQ_CLEAR_INTERRUPT(TIM5IRQ);
	IRQ_ENABLE_INTERRUPT(TIM5IRQ);

}



