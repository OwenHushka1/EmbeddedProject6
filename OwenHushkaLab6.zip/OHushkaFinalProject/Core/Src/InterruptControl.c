

#include<InterruptControl.h>

void IRQ_ENABLE_INTERRUPT(uint8_t IRQ_NUM){
	if(IRQ_NUM < 32){
		*NVIC_ISER0 |= (1 << IRQ_NUM);
	}
	else{
		*NVIC_ISER1 |= (1 << (IRQ_NUM % 32));
	}

}

void IRQ_DISABLE_INTERRUPT(uint8_t IRQ_NUM){
	if(IRQ_NUM < 32){
		*NVIC_ICER0 |= (1 << IRQ_NUM);
		}
	else{
		*NVIC_ICER1 |= (1 << (IRQ_NUM % 32));
	}
}

void IRQ_CLEAR_INTERRUPT(uint8_t IRQ_NUM){

	if(IRQ_NUM < 32){
		*NVIC_ICPR0 |= (1 << IRQ_NUM);
		}
	else{
		*NVIC_ICPR1 |= (1 << (IRQ_NUM % 32));
	}

}

void IRQ_SET_INTERRUPT(uint8_t  IRQ_NUM){

	if(IRQ_NUM < 32){
		*NVIC_ISPR0 |= (1 << IRQ_NUM);
		}
	else{
		*NVIC_ISPR1 |= (1 << (IRQ_NUM % 32));
	}
}

void EXTI_INTERRUPT_CLEAR(uint8_t pin_num){

	EXTI->PR |= (1 << pin_num);

}


void IRQ_ConfigurePriority(uint8_t IRQ_NUM, uint8_t IRQ_priority){
	uint8_t reg = IRQ_priority / 4;
	uint8_t bitField = IRQ_priority % 4;
	uint8_t shift = bitField * 8;
	*(NVIC_IPR0 + reg) &= ~(0xFF << shift);
	*(NVIC_IPR0 + reg) |= (0xFF << shift);

}


