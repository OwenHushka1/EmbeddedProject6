#include<Timer_Driver.h>

#define CLKDIVOFFSET 8
#define CENTER_ALLIGNED_OFFSET 5

#define DIR_BIT_SHIFT 4
#define AUTO_RELOAD_BUFFER 7
#define PULSE_ENABLE 3
#define UPDATE_EVENT_BUFFER 1
#define OUTPUT_COMPARE_BIT 4
#define CAPTURE_COMPARE_BIT 0
#define CLEAR_ENABLE_BIT 7


void InitTimer(Timer_Handle_t *timer){

	uint32_t temp;
	//clear and set clock division bit field
	temp = (timer->config.CLKDIV << CLKDIVOFFSET);
	timer->timer->CR1 &= ~(0x3 << CLKDIVOFFSET); //clearing bits 8 and 9 of CR1
	timer->timer->CR1 |= temp;//setting the 8th and 9th bits from timer->tim
	//bits 9 and 8

	//center aligned mode
	temp = (timer->config.centerAlignedMode << CENTER_ALLIGNED_OFFSET);
	timer->timer->CR1 &= ~(0x3 << CENTER_ALLIGNED_OFFSET); //clearing bits 6 and 5 of CR1
	timer->timer->CR1 |= temp; //setting the 6th and 5th bits from timer->tim


	//setting direction (Bit 4)
	if(timer->config.dir){
		//set bit 4 of CR1
		timer->timer->CR1 |= (1 << DIR_BIT_SHIFT);

	}
	else{
		//clear bit 4 of CR1
		timer->timer->CR1 &= ~(1 << DIR_BIT_SHIFT);
	}


	//timer.config.AutoReloadBufferEnable    bit 7
	if(timer->config.AutoReloadBufferEnable){
		//set bit 7
		timer->timer->CR1 |= (1 << AUTO_RELOAD_BUFFER);
	}
	else{
		//clear bit 7
		timer->timer->CR1 &= ~(1 << AUTO_RELOAD_BUFFER);
	}
	timer->timer->DIER |= (0x3 << 0);

	//entire register is just for that value so dont need to shifts
	//for auto reload value


	//timer.config.PulseEnable    bit 3
	if(timer->config.PulseEnable){
		//set bit 3
		timer->timer->CR1 |= (1 << PULSE_ENABLE);
	}
	else{
		//clear bit 3
		timer->timer->CR1 &= ~(1 << PULSE_ENABLE);
	}



	//timer.config.DisableUpdateEvent    bit 1
	if(timer->config.DisableUpdateEvent){
		//set bit 3
		timer->timer->CR1 |= (1 << UPDATE_EVENT_BUFFER);
	}
	else{
		//clear bit 1
		timer->timer->CR1 &= ~(1 << UPDATE_EVENT_BUFFER);
	}


	//timer.config.InterruptUpdateEnable
	if(timer->config.InterruptUpdateEnable){
		//set bit 0
		timer->timer->DIER |= (1);
	}
	else{
		//clear bit 0
		timer->timer->DIER &= ~(1);
	}


	//store prescaler value
	timer->timer->PSC = timer->config.prescalerVal;


	//volatile uint32_t ARR; //31:16 High auto-reload value. 15:0 Auto-reload value
	//store auto reload value
	timer->timer->ARR = timer->config.AutoReloadVal;
	//need to check channel config to see if the interrupt is enabled
	//need to check timer config to see if the interrupt is enabled
	//if either are then we need to set that




	InitChannel1(timer);

	if(timer->config.channelConfig.interruptEnable || timer->config.InterruptUpdateEnable){
		//IRQ_ENABLE_INTERRUPT()
		//need IRQ value -- should have these for timer 2 and timer 5
		//TimerInterrupt(timer->timer);//?? NEed to pass an "able" value
		TimerInterrupt(timer->timer, ENABLE);
	}
}



void InitChannel1(Timer_Handle_t *timer){  //I think i need to specify which timer tbhhh

	uint32_t temp;

	//output compare 1 (bits 4-6)
	temp = (timer->config.channelConfig.outputCompare << OUTPUT_COMPARE_BIT);
	timer->timer->CCMR1 &= ~(0x7 << OUTPUT_COMPARE_BIT); //clearing bits 4-6 of CCMR1
	timer->timer->CCMR1 |= temp;  //0111 0000 = 0x70



	//Clear and set the appropriate bits in the CCMR1 register for the output compare mode
	//Clear and set the appropriate bits in the CCMR1 register for the capture/compare selection mode
	//bits 0 and 1
	temp = (timer->config.channelConfig.captureCompare << CAPTURE_COMPARE_BIT);
	timer->timer->CCMR1 &= ~(0x3 << CAPTURE_COMPARE_BIT); //clearing bits 0 and 1 of CCMR1
	timer->timer->CCMR1 |= temp;  //0111= 0x3


	//clear enable is bit 7
	if(timer->config.channelConfig.clearEnable){
		timer->timer->CCMR1 |= (1 << 7);  //0111= 0x3
	}
	else{
		timer->timer->CCMR1 &= ~(1 << 7); //clearning bit 7
	}



	if(timer->config.channelConfig.preloadEnable){
		timer->timer->CCMR1 |= (1 << 7);  //0111= 0x3
	}
	else{
		timer->timer->CCMR1 &= ~(1 << 7); //clearing bit 7
	}
	//Configure the appropriate bit in the CCMR1 register if output compare clear enable should be enabled or not


	if(timer->config.channelConfig.interruptEnable){
		timer->timer->DIER |= (1 << 7);  //0111= 0x3
	}
	else{
		timer->timer->DIER &= ~(1 << 7); //clearing bit 7
	}
	timer->timer->CCR1 = timer->config.channelConfig.captureCompare; //store capture compare value in CCR1


}

void ClockControl(GPTIMR_RegDef_t timer, uint8_t able){  //probably need to specify clock or channel or something
	if(able == 1){
		APB1_CLK_ENABLE(1);
	}
	else{
		APB1_CLK_DISABLE(1);//disable bit 3 for tim5 and bit 0 for tim2
	}
	//TIM5_OFFSET
	//TIM2_OFFSET
	//APB1_BASE_ADDR

}

void StartTimer(GPTIMR_RegDef_t* timer){

	timer->CR1 |= 1;

}

void StopTimer(GPTIMR_RegDef_t* timer){

	timer->CR1 &= ~1;
}

void ResetTimer(GPTIMR_RegDef_t* timer){

	timer->CNT = 0;
}

uint32_t ReturnTimer(GPTIMR_RegDef_t* timer){

	return timer->CNT;
}

void TimerInterrupt(GPTIMR_RegDef_t *timer, uint8_t able){

	//timer == TIM2

	if(able == ENABLE){
		if(timer == TIM2){
			IRQ_ENABLE_INTERRUPT(28); //28 for TIM2, 50 for TIM5
		}
		if(timer == TIM5){
			IRQ_ENABLE_INTERRUPT(50);
		}
	}
	else{
		if(timer == TIM2){
			IRQ_DISABLE_INTERRUPT(28); //28 for TIM2, 50 for TIM5
}
		if(timer == TIM5){
			IRQ_DISABLE_INTERRUPT(50); //28 for TIM2, 50 for TIM5
				}

	}
}

void SetPriority(GPTIMR_RegDef_t *timer, uint8_t priority){

	//IRQ_ConfigurePriority(uint8_t IRQ_NUM, uint8_t IRQ_priority)
	if(timer == TIM2){
		IRQ_ConfigurePriority(28, priority);
	}
	if(timer == TIM5){
		IRQ_ConfigurePriority(50, priority);
	}


}


