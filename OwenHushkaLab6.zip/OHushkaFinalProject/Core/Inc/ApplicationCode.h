/*
 * ApplicationCode.h
 *
 *  Created on: Nov 14, 2023
 */

#ifndef INC_APPLICATIONCODE_H_
#define INC_APPLICATIONCODE_H_


#define NAME_LENGTH 4
#define DELAY 200000
#include<Scheduler.h>
#include <stdint.h>
#include<LCD_Driver.h>
#include<RNG_Driver.h>
#include<Timer_Driver.h>
#include "LCD_Driver.h"
#include "RNG_Driver.h"




#define AHB1_CLK_ENABLE(bit) (RCC->AHB1ENR |= 1<<bit)
#define AHB1_CLK_DISABLE(bit) (RCC->AHB1ENR &= ~1<<bit)
#define APB2_CLK_ENABLE(bit) (RCC->APB2ENR |= 1<<bit)
#define APB2_CLK_DISABLE(bit) (RCC->APB2ENR &= ~1<<bit)
#define APB1_CLK_ENABLE(bit) (RCC->APB1ENR |= 1<<bit)
#define APB1_CLK_DISABLE(bit) (RCC->APB1ENR &= ~1<<bit)

#define USE_INTERRUPT_FOR_BUTTON 1
#define USE_LIMITED_RESOURCES 1


//bit mask to clear the event which signals that the button has been pressed
#define BUTTON_EVENT_CLEAR 4294967291
//11111111111111111111111111111011 in binary

#if USE_INTERRUPT_FOR_BUTTON == 1
	void InitializeInterruptMode();
#elif USE_INTERRUPT_FOR_BUTTON ==0
	void Button_Init();
#endif


void ApplicationInit(void);
void RunDemoForLCD(void);
void PrintInstruction();
void printInstruction2();
void printInstruction3();


int SeperateCharacters(uint32_t num, uint8_t *arr);
void CharactersToAscii(char *arr, int size);
int GetNumDigits(uint32_t num);
void PrintInstructions();
//void Application_Init();

void DelayTime(uint32_t num, RNG_HandleTypeDef RNG_Handle);
void Delay();


#endif /* INC_APPLICATIONCODE_H_ */
