


#ifndef INC_BUTTON_DRIVER_H_
#define INC_BUTTON_DRIVER_H_

#include<stdbool.h>
#include<InterruptControl.h>
//#include"GPIO_Driver.h"



#define BUTTON_PORT GPIOA //macro to store button's port value
#define BUTTON_PIN GPIO_PIN_0 //macro to store button's pin value
#define BUTTON_PRESSED 1
#define BUTTON_NOT_PRESSED 0


void Initialize_Button();
void Enable_Clock();
bool Return_Press();
void Initialize_Interrupt_Mode();

#endif /* INC_BUTTON_DRIVER_H_ */
